﻿using System;
using System.Net;
using System.Reflection;
using System.Runtime.Serialization;
using System.Collections.Generic;
using System.Linq.Expressions;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.EventReceivers;

//namespace SharePoint.Client.Extensions
namespace BasicDataOperationsWeb
{
    public static class SiteExtensions
    {
        public static List<Web> EnumAllWebs(this Site site, params  Expression<Func<Web, object>>[] retrievals)
        {
            var ctx = site.Context;
            var rootWeb = site.RootWeb;
            ctx.Load(rootWeb, retrievals);
            var result = new List<Web>();
            result.Add(rootWeb);
            EnumAllWebsInner(rootWeb, result, retrievals);
            return result;
        }

        private static void EnumAllWebsInner(Web parentWeb, ICollection<Web> result, params  Expression<Func<Web, object>>[] retrievals)
        {
            var ctx = parentWeb.Context;
            var webs = parentWeb.Webs;
            ctx.Load(webs, wcol => wcol.Include(retrievals));
            ctx.ExecuteQuery();
            foreach (var web in webs)
            {
                result.Add(web);
                EnumAllWebsInner(web, result, retrievals);
            }
        }
        //
        public static void EnumAllWebsAddEvent(this Site site, string listName, string isInstall)
        {
            var ctx = site.Context;
            var rootWeb = site.RootWeb;
            ctx.Load(rootWeb);
            ctx.ExecuteQuery();
            var result = new List<Web>();
            result.Add(rootWeb);

            var documentsList = rootWeb.Lists.GetByTitle("TestSource");
            ctx.Load(documentsList);
            ctx.ExecuteQuery();

            if (isInstall == "YES")
            {
                string remoteUrl = "https://lacoeedu.azurewebsites.net/RemoteEventReceiver1.svc";
                //Create the remote event receiver definition
                EventReceiverDefinitionCreationInformation newEventReceiver = new EventReceiverDefinitionCreationInformation()
                           {
                               //EventType = EventReceiverType.ItemAdded,
                               EventType = EventReceiverType.ItemUpdated,
                               ReceiverAssembly = Assembly.GetExecutingAssembly().FullName,
                               ReceiverName = "RemoteEventReceiver1",
                               ReceiverClass = "RemoteEventReceiver1",
                               ReceiverUrl = remoteUrl,
                               SequenceNumber = 15000
                           };

                //Add the remote event receiver to the host web list
                documentsList.EventReceivers.Add(newEventReceiver);
                ctx.ExecuteQuery();
                EnumAllWebsInnerAddEvent(rootWeb, result, isInstall);
                // return result;
            }
            else
            {
                //var documentsList = clientContext.Web.Lists.GetByTitle("TestSource");
                //clientContext.Load(list);
                //clientContext.ExecuteQuery();
                EventReceiverDefinitionCollection erdc = documentsList.EventReceivers;
                ctx.Load(erdc);
                ctx.ExecuteQuery();
                List<EventReceiverDefinition> toDelete = new List<EventReceiverDefinition>();
                foreach (EventReceiverDefinition erd in erdc)
                {
                    if (erd.ReceiverName == "RemoteEventReceiver1")
                    {
                        toDelete.Add(erd);
                    }
                }

                //Delete the remote event receiver from the list, when the app gets uninstalled
                foreach (EventReceiverDefinition item in toDelete)
                {
                    item.DeleteObject();
                    ctx.ExecuteQuery();
                }
            }
        }

        
            //return result;


        private static void EnumAllWebsInnerAddEvent(Web parentWeb, ICollection<Web> result, string isInstall)
        {
            var ctx = parentWeb.Context;
            var webs = parentWeb.Webs;
            //ctx.Load(webs, wcol => wcol.Include(retrievals));
            ctx.Load(webs);
            ctx.ExecuteQuery();
            //
            var documentsList = parentWeb.Lists.GetByTitle("TestSource");
            ctx.Load(documentsList);
            ctx.ExecuteQuery();

            if (isInstall == "YES")
            {
                string remoteUrl = "https://lacoeedu.azurewebsites.net/RemoteEventReceiver1.svc";
                //Create the remote event receiver definition
                EventReceiverDefinitionCreationInformation newEventReceiver = new EventReceiverDefinitionCreationInformation()
                {
                    //EventType = EventReceiverType.ItemAdded,
                    EventType = EventReceiverType.ItemUpdated,
                    ReceiverAssembly = Assembly.GetExecutingAssembly().FullName,
                    ReceiverName = "RemoteEventReceiver1",
                    ReceiverClass = "RemoteEventReceiver1",
                    ReceiverUrl = remoteUrl,
                    SequenceNumber = 15000
                };

                //Add the remote event receiver to the host web list
                documentsList.EventReceivers.Add(newEventReceiver);
                ctx.ExecuteQuery();
                foreach (var web in webs)
                {
                    result.Add(web);
                    EnumAllWebsInnerAddEvent(web, result, isInstall);
                }
            }
            else {
                //var documentsList = clientContext.Web.Lists.GetByTitle("TestSource");
                //clientContext.Load(list);
                //clientContext.ExecuteQuery();
                EventReceiverDefinitionCollection erdc = documentsList.EventReceivers;
                ctx.Load(erdc);
                ctx.ExecuteQuery();
                List<EventReceiverDefinition> toDelete = new List<EventReceiverDefinition>();
                foreach (EventReceiverDefinition erd in erdc)
                {
                    if (erd.ReceiverName == "RemoteEventReceiver1")
                    {
                        toDelete.Add(erd);
                    }
                }

                //Delete the remote event receiver from the list, when the app gets uninstalled
                foreach (EventReceiverDefinition item in toDelete)
                {
                    item.DeleteObject();
                    ctx.ExecuteQuery();
                }
 
            }
        }



    }
}