﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.EventReceivers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Channels;
using Microsoft.SharePoint.Client.Social;


namespace BasicDataOperationsWeb
{
    public class KeyContactReceiver : IRemoteEventService
    {
        public SPRemoteEventResult ProcessEvent(SPRemoteEventProperties properties)
        {
            SPRemoteEventResult result = new SPRemoteEventResult();

            using (ClientContext clientContext = TokenHelper.CreateRemoteEventReceiverClientContext(properties))
            {
                if (clientContext != null)
                {
                    clientContext.Load(clientContext.Web);
                    clientContext.ExecuteQuery();
                }
            }

            return result;
        }
        public void ProcessOneWayEvent(SPRemoteEventProperties properties)
        {
            using (ClientContext clientContext = TokenHelper.CreateRemoteEventReceiverClientContext(properties))
            {
                if (clientContext != null)
                {
                    // When new case is added or updated, this is the method that gets triggered
                    if (properties.EventType.Equals(SPRemoteEventType.ItemUpdated))
                    //if (properties.EventType.Equals(SPRemoteEventType.ItemAdded))
                    {
                        var afterProperties = properties.ItemEventProperties.AfterProperties;
                        var beforeProperties = properties.ItemEventProperties.BeforeProperties;

                        if (ShouldSecretBeUpdated(beforeProperties, afterProperties))
                        {
                            try
                            {
                                //string strComments="";
                                //var result = new List<string>();
                                //var webs = clientContext.Site.EnumAllWebs(w => w.Title, w => w.Lists);
                                //foreach (var web in webs)
                                //{
                                //    foreach (var list in web.Lists)
                                //    {
                                //        result.Add(web.Title + list.Title);
                                //    }
                                //}
                                


                                List docLib = clientContext.Web.Lists.GetById(properties.ItemEventProperties.ListId);
                                ListItem item = docLib.GetItemById(properties.ItemEventProperties.ListItemId);
                                clientContext.Load(item);
                                clientContext.ExecuteQuery();
                                //This is just for testing i update word document here
                                string filePath = item["FileRef"].ToString();
                                item["Title"] = "NEW Title " + System.DateTime.Now.ToLongTimeString();
                                //item["_Comments"] = strComments;
                                ////////////////////////////////////////////////
                                item.Update();
                                clientContext.ExecuteQuery();
                                
                                



                            }
                            catch (Exception oops)
                            {
                                System.Diagnostics.Trace.WriteLine(oops.Message);
                            }
                        }
                    }
                }
            }
        }
        private static bool ShouldSecretBeUpdated(
            IReadOnlyDictionary<string, object> beforeProperties,
            IReadOnlyDictionary<string, object> afterProperties)
        {
            // If the property doesn't exist, then the secret should be updated
            if (!beforeProperties.ContainsKey("IsApproved") || !afterProperties.ContainsKey("IsApproved"))
            {
                return true;
            }
            //// If the value of IsSecret differ, then secret should be updated
            return afterProperties["IsApproved"].ToString() != beforeProperties["IsApproved"].ToString();
        }
        //public void ProcessOneWayEvent(SPRemoteEventProperties properties)
        //{
        //   // On Item Added event, the list item creation executes
        //   if(properties.EventType == SPRemoteEventType.ItemAdded){
        //       if (string.Equals(properties.ItemEventProperties.ListTitle, "Feedback",
        //          StringComparison.OrdinalIgnoreCase))
        //           return;

        //    using (ClientContext clientContext = TokenHelper.CreateRemoteEventReceiverClientContext(properties))
        //    {
        //        if (clientContext != null)
        //        {
        //            try
        //            {
        //                clientContext.Load(clientContext.Web);
        //                clientContext.ExecuteQuery();
        //                List imageLibrary = clientContext.Web.Lists.GetByTitle("Feedback");
        //                ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
        //                ListItem oListItem = imageLibrary.AddItem(itemCreateInfo);
        //                oListItem["Title"] = "TITLE CHANGED BY RER";
        //                oListItem.Update();

        //                clientContext.ExecuteQuery();
                        
        //            }
        //            catch (Exception ex)
        //            {
                       

        //            }

        //        }
        //    }
        //  }


        //}

    }

}
